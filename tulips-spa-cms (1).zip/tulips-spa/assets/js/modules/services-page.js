/**
 * "Üzleti szolgáltatások Budapesten" – részletes szolgáltatás-aloldal (/uzleti-szolgaltatasok-budapest, /business-services-budapest).
 * Minden szöveg az i18n JSON "sp.*" kulcsaiból jön. A tartalom előrenderelve is elkészül (prerender.py), hogy a keresők és az
 * AI-asszisztensek JavaScript nélkül is lássák; ide a hozzá tartozó strukturált adat (JSON-LD) is bekerül.
 */
import { $, esc } from './dom.js';
import { t, getLang } from './i18n.js';
import { SITE } from '../config.js';
import { SERVICES } from '../data/services.js';
import { pageHero, ctaBand } from './components.js';
import { heroScene } from './scenes.js';
import { observeReveal } from './reveal.js';
import { navigate } from './router.js';
import { pickOption } from './form.js';

export const PATHS = { hu: '/uzleti-szolgaltatasok-budapest', en: '/business-services-budapest' };
export const pagePath = () => (getLang() === 'hu' ? PATHS.hu : PATHS.en);

/** Számozott i18n-lista (kulcs.0, kulcs.1 …) – addig olvas, amíg van kulcs. */
const list = (p) => { const out = []; for (let i = 0; ; i++) { const k = `${p}.${i}`, v = t(k); if (v === k) break; out.push(v); } return out; };
const pairs = (p) => { const out = []; for (let i = 0; ; i++) { const a = `${p}.${i}.0`, v = t(a); if (v === a) break; out.push([v, t(`${p}.${i}.1`)]); } return out; };
const svcTitle = (s) => t(`services.${s.code}.title`);

function ld() {
  const url = SITE + pagePath();
  const faq = pairs('sp.faq');
  const graph = [
    {
      '@type': 'WebPage', '@id': url + '#page', url, name: t('meta.title.services'), description: t('meta.desc.services'),
      inLanguage: getLang() === 'hu' ? 'hu-HU' : 'en', isPartOf: { '@id': SITE + '/#website' }, about: { '@id': SITE + '/#org' },
      breadcrumb: { '@id': url + '#crumbs' },
    },
    {
      '@type': 'BreadcrumbList', '@id': url + '#crumbs',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: t('ui.home'), item: SITE + '/' },
        { '@type': 'ListItem', position: 2, name: t('sp.crumb'), item: url },
      ],
    },
    {
      '@type': ['Organization', 'ProfessionalService'], '@id': SITE + '/#org', name: 'TULIPS GROUP', url: SITE + '/',
      logo: SITE + '/assets/img/logo.png', email: 'info@tulipsgroup.hu', description: t('sp.ldDesc'),
      address: { '@type': 'PostalAddress', addressLocality: 'Budapest', addressCountry: 'HU' },
      areaServed: [{ '@type': 'Country', name: 'Hungary' }, { '@type': 'Place', name: 'European Union' }],
      hasOfferCatalog: {
        '@type': 'OfferCatalog', name: t('sp.crumb'),
        itemListElement: SERVICES.map((s) => ({
          '@type': 'Offer',
          itemOffered: {
            '@type': 'Service', name: t(`sp.svc.${s.code}.h`), serviceType: svcTitle(s),
            description: t(`sp.svc.${s.code}.lead`), identifier: `TEÁOR/NACE ${s.code}`,
            provider: { '@id': SITE + '/#org' }, areaServed: { '@type': 'City', name: 'Budapest' },
            url: `${url}#teaor-${s.code}`,
          },
        })),
      },
    },
    { '@type': 'FAQPage', '@id': url + '#faq', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) },
  ];
  return { '@context': 'https://schema.org', '@graph': graph };
}

function setLd() {
  let el = document.getElementById('ld-services');
  if (!el) { el = document.createElement('script'); el.type = 'application/ld+json'; el.id = 'ld-services'; document.head.appendChild(el); }
  el.textContent = JSON.stringify(ld());
}

function html() {
  const facts = pairs('sp.facts').map(([k, v]) => `<li><b>${esc(k)}</b>${esc(v)}</li>`).join('');
  const index = SERVICES.map((s) => `<li><a href="#teaor-${s.code}"><span>${esc(svcTitle(s))}</span><small>${s.code}</small></a></li>`).join('');
  const blocks = SERVICES.map((s, i) => {
    const items = list(`sp.svc.${s.code}.items`).map((x) => `<li>${esc(x)}</li>`).join('');
    return `<article class="sp-svc rv" id="teaor-${s.code}"><div class="sp-svc-h"><span class="sp-code">${esc(t('label.code'))} ${s.code}</span><h2>${esc(t(`sp.svc.${s.code}.h`))}</h2></div>`
      + `<div class="sp-svc-b"><div><p class="sp-lead" style="font-size:1.1rem">${esc(t(`sp.svc.${s.code}.lead`))}</p><h3>${esc(t('sp.doH'))}</h3><ul>${items}</ul></div>`
      + `<div class="when"><h3>${esc(t('sp.whenH'))}</h3><p>${esc(t(`sp.svc.${s.code}.when`))}</p><button class="btn p" type="button" data-pre="${i + 2}">${esc(t('sp.cta'))}</button></div></div></article>`;
  }).join('');
  const steps = pairs('sp.steps').map(([h, p]) => `<li><b>${esc(h)}</b><span>${esc(p)}</span></li>`).join('');
  const aud = pairs('sp.aud').map(([h, p]) => `<div><h3>${esc(h)}</h3><p>${esc(p)}</p></div>`).join('');
  const faq = pairs('sp.faq').map(([q, a], i) => `<details class="q"${i === 0 ? ' open' : ''}><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('');
  return pageHero({ title: t('sp.h1'), sub: t('sp.sub'), crumb: t('sp.crumb'), scene: heroScene('art') })
    + `<section class="sec"><div class="w"><p class="sp-lead rv">${esc(t('sp.intro'))}</p><ul class="sp-facts rv">${facts}</ul></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><div class="rv"><h2>${esc(t('sp.idxTitle'))}</h2><p style="color:#3d4560;max-width:46em">${esc(t('sp.idxLead'))}</p></div><ul class="sp-index rv">${index}</ul></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w">${blocks}</div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><div class="rv"><h2>${esc(t('sp.stepsH'))}</h2><p style="color:#3d4560;max-width:46em">${esc(t('sp.stepsLead'))}</p></div><ol class="sp-steps rv">${steps}</ol></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><h2 class="rv">${esc(t('sp.audH'))}</h2><div class="sp-aud rv">${aud}</div></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w" style="max-width:860px"><h2 class="rv">${esc(t('sp.faqH'))}</h2><div class="fq rv">${faq}</div></div></section>`
    + ctaBand('sp.ctaH');
}

function bind(el) {
  if (el.dataset.bound) return; el.dataset.bound = '1';
  el.addEventListener('click', (e) => {
    const b = e.target.closest('[data-pre]'); if (!b) return;
    pickOption(+b.dataset.pre); navigate('/kapcsolat');
  });
}

export async function render(el) {
  el.innerHTML = html(); setLd(); bind(el); observeReveal(el);
}
export const update = async () => {};
export const rerender = () => { const el = $('#view-services'); el.innerHTML = html(); setLd(); observeReveal(el); };
export const title = () => t('meta.title.services');
