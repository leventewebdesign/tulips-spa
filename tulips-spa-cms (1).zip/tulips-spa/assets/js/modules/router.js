/**
 * History API alapú router (SPA): pushState / popstate, URL-átírás újratöltés nélkül.
 * Nézetek (views): home, blog, faq, why, privacy, terms – a router megjeleníti / elrejti őket.
 * Linkek: bármely belső <a href="/blog"> automatikusan SPA-navigáció (Ctrl/⌘-kattintás, új lap: marad a böngésző alapértelmezése).
 */
import { BASE, ROUTES, SITE } from './../config.js';
import { $, prefersReducedMotion, raf } from './dom.js';
import { t } from './i18n.js';
import { withCurtain } from './transitions.js';

const views = {};
let cur = { view: null, path: null, route: null, params: {} };

export const registerView = (name, impl) => { views[name] = impl; };
const norm = (p) => ('/' + String(p).replace(/^\/+/, '')).replace(/\/+$/, '') || '/';
export const toPath = (loc = location) => norm(loc.pathname.startsWith(BASE) ? loc.pathname.slice(BASE.length - 1) : loc.pathname);
export const currentRoute = () => cur;

function match(path) {
  const ps = path.split('/');
  for (const route of ROUTES) {
    const rs = route.path.split('/');
    if (rs.length !== ps.length) continue;
    const params = {}; let ok = true;
    rs.forEach((s, i) => { if (s.startsWith(':')) params[s.slice(1)] = decodeURIComponent(ps[i]); else if (s !== ps[i]) ok = false; });
    if (ok) return { route, params };
  }
  return null;
}

async function render(path, { first = false } = {}) {
  let m = match(path);
  if (!m) { m = { route: ROUTES[0], params: {} }; try { history.replaceState({}, '', BASE); } catch (e) { /* */ } path = '/'; }
  const { route, params } = m, v = views[route.view], changed = route.view !== cur.view;

  const apply = async () => {
    if (changed) {
      Object.entries(views).forEach(([n, x]) => { x.el.hidden = n !== route.view; });
      await v.enter?.(params, route);
      window.scrollTo({ top: 0, behavior: 'instant' });
    } else await v.update?.(params, route);
    cur = { view: route.view, path, route, params };
    document.title = v.title?.(params) || t(route.title);
    setSeo(route, path);
    document.dispatchEvent(new CustomEvent('routechange', { detail: { path, route, params, changed } }));
    await raf();
    const id = route.anchor || v.anchor?.(params);
    const target = id && document.getElementById(id);
    if (target) target.scrollIntoView({ behavior: changed || prefersReducedMotion() ? 'auto' : 'smooth', block: 'start' });
    else if (!changed) window.scrollTo({ top: 0, behavior: prefersReducedMotion() ? 'auto' : 'smooth' });
    announce(changed, target);
  };
  if (changed && !first) await withCurtain(apply); else await apply();
}

/** Leírás + kanonikus URL + strukturált adat az aktuális nézethez (a statikus főoldali értékek visszaállnak). */
function setSeo(route, path) {
  const d = document.querySelector('meta[name="description"]');
  if (d) { d.dataset.def = d.dataset.def || d.content; d.content = route.view === 'services' ? t('meta.desc.services') : d.dataset.def; }
  const c = document.querySelector('link[rel="canonical"]');
  if (c) c.href = SITE + (route.view === 'home' ? '/' : path);
  if (route.view !== 'services') document.getElementById('ld-services')?.remove();
}

/** Képernyőolvasó értesítés + fókuszkezelés navigáció után. */
function announce(changed, target) {
  const live = $('#a11y-status'), main = $('#main');
  if (live) { live.textContent = ''; setTimeout(() => { live.textContent = t('a11y.navigated', { title: document.title }); }, 60); }
  if (target && !changed) { target.setAttribute('tabindex', '-1'); target.focus({ preventScroll: true }); }
  else if (main) main.focus({ preventScroll: true });
}

export async function navigate(path, { replace = false } = {}) {
  path = norm(path);
  if (path !== cur.path || replace) {
    const url = BASE + path.replace(/^\//, '');
    try { history[replace ? 'replaceState' : 'pushState']({ path }, '', url); }
    catch (e) { location.href = url; return; }
  }
  await render(path);
}

export function startRouter() {
  addEventListener('popstate', () => { const p = toPath(); if (p === cur.path && location.hash) return; render(p); }); // csak a #horgony változott: a böngésző görget
  document.addEventListener('langchange', () => {
    const v = views[cur.view];
    if (!v) return;
    v.rerender?.(cur.params, cur.route);
    document.title = v.title?.(cur.params) || t(cur.route.title);
  });
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || a.target || a.hasAttribute('download')) return;
    const u = new URL(a.href, location.href);
    if (u.origin !== location.origin) return;
    if (u.hash && u.pathname === location.pathname) return; // oldalon belüli horgony: a böngésző görgeti (scroll-margin-top)
    const p = toPath(u);
    if (!match(p) || (u.pathname.startsWith(BASE) === false)) return;
    e.preventDefault();
    navigate(p);
  });
  return render(toPath(), { first: true });
}
