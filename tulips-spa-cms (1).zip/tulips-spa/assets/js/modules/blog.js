/** Blog / Hírek modul. Új cikk: vegyél fel egy elemet az assets/data/articles.json-ba + a szövegeket az i18n JSON-okba. */
import { $, esc } from './dom.js';
import { t } from './i18n.js';
import { BASE } from '../config.js';
import { pageHero, ctaBand } from './components.js';
import { heroScene, plainsScene, bridgeScene } from './scenes.js';
import { observeReveal } from './reveal.js';

let articles = null, spy;
export async function loadArticles() {
  if (!articles) articles = await (await fetch(`${BASE}assets/data/articles.json`)).json();
  return articles;
}
const find = (slug) => articles?.find((a) => a.slug === slug);

/* ---- főoldali hírkártyák (#hirek) ---- */
export async function renderNewsCards() {
  const box = $('#news-grid'); if (!box) return;
  const list = await loadArticles();
  box.innerHTML = list.map((a) => `<article class="card"><time datetime="${a.date}">${esc(t(a.keys.date))}</time><h3>${esc(t(a.keys.title))}</h3><p>${esc(t(a.keys.lead))}</p><a class="more" href="/blog/${a.slug}"><span>${esc(t('news.more'))}</span><i class="arr" aria-hidden="true">→</i></a></article>`).join('');
}

/* ---- blog nézet ---- */
const scene = (a) => ({ parl: () => heroScene('art'), bridge: bridgeScene, plain: plainsScene }[a.scene] || heroScene)();
function articleHtml(a) {
  const secs = a.sections.map((s) => `<h3>${esc(t(s.h))}</h3><p>${esc(t(s.p))}</p>`).join('');
  const flow = a.flow.map((k, j) => `<li style="--k:${j}"><i>${j + 1}</i><span>${esc(t(k))}</span></li>`).join('');
  const tk = a.takeaways.map((k) => `<li>${esc(t(k))}</li>`).join('');
  const st = a.scene === 'plain' ? ' style="background:linear-gradient(180deg,#06205c,#0e4a8c)"' : '';
  return `<article class="art-card rv" id="${a.id}"><div class="art-img"${st}>${scene(a)}</div><div class="art-body"><time datetime="${a.date}">${esc(t(a.keys.date))}</time><h2>${esc(t(a.keys.title))}</h2><p class="lead2">${esc(t(a.keys.lead))}</p><p>${esc(t(a.keys.intro))}</p>${secs}<ol class="flow">${flow}</ol><div class="tk"><h4>${esc(t('ui.key'))}</h4><ul>${tk}</ul></div></div></article>`;
}

export async function render(el) {
  const list = await loadArticles();
  const toc = list.map((a) => `<li><a href="/blog/${a.slug}" data-art="${a.id}">${esc(t(a.keys.title))}</a></li>`).join('');
  el.innerHTML = pageHero({ title: t('blog.h1'), sub: t('blog.sub'), scene: bridgeScene() })
    + `<div class="w blog-wrap"><aside class="toc" aria-label="${esc(t('ui.contents'))}"><h4>${esc(t('ui.contents'))}</h4><ol>${toc}</ol></aside><div class="arts">${list.map(articleHtml).join('')}<p class="disc">${esc(t('blog.disc'))}</p></div></div>`
    + ctaBand();
  observeReveal(el);
  startSpy(el);
}
export const update = async () => {};
export const anchor = (params) => find(params.slug)?.id || null;
export const title = (params) => { const a = find(params.slug); return a ? `${t(a.keys.title)} – TULIPS GROUP` : t('meta.title.blog'); };
export const rerender = () => render($('#view-blog'));

/** tartalomjegyzék: az éppen olvasott cikk kiemelése (aria-current) */
function startSpy(el) {
  spy?.disconnect();
  const links = [...el.querySelectorAll('.toc a')], targets = links.map((a) => el.querySelector('#' + a.dataset.art));
  spy = new IntersectionObserver((es) => es.forEach((e) => {
    if (!e.isIntersecting) return;
    const i = targets.indexOf(e.target);
    links.forEach((a, j) => { a.classList.toggle('on', j === i); j === i ? a.setAttribute('aria-current', 'true') : a.removeAttribute('aria-current'); });
  }), { rootMargin: '-35% 0px -55% 0px' });
  targets.forEach((x) => x && spy.observe(x));
}
