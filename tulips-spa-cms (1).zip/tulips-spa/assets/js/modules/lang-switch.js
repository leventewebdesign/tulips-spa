/**
 * Nyelvválasztó – WAI-ARIA "listbox" minta (aria-haspopup, aria-expanded, aria-activedescendant).
 * Billentyűk: Enter/Space/↓/↑ nyit; ↑ ↓ Home End lép; Enter/Space választ; Esc zár (fókusz a gombra); Tab zár; betűgépelés = ugrás.
 */
import { $, $$ } from './dom.js';
import { getLang, setLang } from './i18n.js';

export function initLangSwitch() {
  const root = $('[data-ls]');
  if (!root) return;
  const btn = $('.ls-b', root), list = $('.ls-m', root), opts = $$('li', root), label = $('.ls-c', root);
  opts.forEach((li, i) => { li.id = 'ls-opt-' + li.dataset.l; li.style.setProperty('--i', i); li.removeAttribute('tabindex'); });
  let active = 0, typed = '', typedTimer;

  const sync = () => {
    const cur = getLang();
    label.textContent = cur.toUpperCase();
    opts.forEach((li) => li.setAttribute('aria-selected', String(li.dataset.l === cur)));
  };
  const setActive = (i) => {
    active = (i + opts.length) % opts.length;
    opts.forEach((li, j) => li.classList.toggle('is-active', j === active));
    list.setAttribute('aria-activedescendant', opts[active].id);
  };
  const isOpen = () => root.classList.contains('open');
  const open = () => {
    root.classList.add('open'); btn.setAttribute('aria-expanded', 'true');
    setActive(Math.max(0, opts.findIndex((li) => li.dataset.l === getLang())));
    list.focus({ preventScroll: true });
  };
  const close = (returnFocus = true) => {
    root.classList.remove('open'); btn.setAttribute('aria-expanded', 'false');
    list.removeAttribute('aria-activedescendant'); opts.forEach((li) => li.classList.remove('is-active'));
    if (returnFocus) btn.focus();
  };
  const choose = (i) => { setLang(opts[i].dataset.l); close(); };

  btn.addEventListener('click', (e) => { e.stopPropagation(); isOpen() ? close() : open(); });
  btn.addEventListener('keydown', (e) => { if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) { e.preventDefault(); if (!isOpen()) open(); } });
  list.addEventListener('keydown', (e) => {
    const k = e.key;
    if (k === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
    else if (k === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
    else if (k === 'Home') { e.preventDefault(); setActive(0); }
    else if (k === 'End') { e.preventDefault(); setActive(opts.length - 1); }
    else if (k === 'Enter' || k === ' ') { e.preventDefault(); choose(active); }
    else if (k === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    else if (k === 'Tab') { close(false); }
    else if (k.length === 1) {
      typed += k.toLowerCase(); clearTimeout(typedTimer); typedTimer = setTimeout(() => { typed = ''; }, 600);
      const i = opts.findIndex((li) => li.textContent.toLowerCase().includes(typed) || li.dataset.l.startsWith(typed));
      if (i >= 0) setActive(i);
    }
  });
  opts.forEach((li, i) => { li.addEventListener('click', () => choose(i)); li.addEventListener('mousemove', () => setActive(i)); });
  document.addEventListener('click', (e) => { if (isOpen() && !root.contains(e.target)) close(false); });
  document.addEventListener('langchange', sync);
  sync();
}
