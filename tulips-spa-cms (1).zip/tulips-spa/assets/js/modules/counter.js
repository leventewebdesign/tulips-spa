/** "9%" számláló: 35%-ról csökken 9%-ra, a szám mérete csak csökken; csak a szakaszból kilépve indul újra. */
import { prefersReducedMotion } from './dom.js';

const A = 35, Z = 9, K = 1.3;

export function initTaxCounters(root = document) {
  root.querySelectorAll('.nine').forEach((card) => {
    if (card.dataset.bound) return; card.dataset.bound = '1';
    const n = card.querySelector('[data-tax]'), b = card.querySelector('[data-tax-bar]');
    if (!n || !b) return;
    let raf, armed = true;
    const set = (v, k) => { n.textContent = Math.round(v) + '%'; b.style.width = v + '%'; n.style.transform = k > 1.001 ? `scale(${k.toFixed(3)})` : ''; };
    set(A, K);
    const go = () => {
      cancelAnimationFrame(raf);
      if (prefersReducedMotion()) { set(Z, 1); return; }
      const t0 = performance.now(), D = 1400;
      const step = (t) => { const p = Math.min((t - t0) / D, 1), e = 1 - Math.pow(1 - p, 3); set(A - (A - Z) * e, K - (K - 1) * e); if (p < 1) raf = requestAnimationFrame(step); };
      raf = requestAnimationFrame(step);
    };
    new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting && armed) { armed = false; go(); } }), { threshold: 0.35 }).observe(card);
    new IntersectionObserver((es) => es.forEach((e) => { if (!e.isIntersecting) { armed = true; cancelAnimationFrame(raf); set(A, K); } }), { threshold: 0 }).observe(card);
  });
}
