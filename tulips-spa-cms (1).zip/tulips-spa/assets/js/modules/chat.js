/** "Tulips munkatér" animált demó (hero): jelenetek, méretezés, mobilon áthelyezés a hero alá. */
import { $, $$ } from './dom.js';
import { t } from './i18n.js';
import { CHAT } from '../data/chat.js';

export function initChat() {
  const feed = $('#feed'), dots = $('#dots'), mock = $('.mock'), home = mock.parentNode;
  let sc = 0, token = 0, timer;
  dots.innerHTML = CHAT.map(() => '<i></i>').join('');

  const bubble = (m) => `<div class="bub ${m.ok ? 'ok' : ''}">${t(m.key + '.text')}<small>${t(m.key + '.sub')}</small></div>`;

  function run() {
    clearTimeout(timer);
    const my = ++token, d = CHAT[sc];
    $('#scn').textContent = t(d.key + '.name');
    feed.innerHTML = '';
    $$('#dots i').forEach((e, j) => e.classList.toggle('on', j === sc));
    d.msgs.forEach((m, i) => setTimeout(() => { if (my === token) feed.insertAdjacentHTML('beforeend', bubble(m)); }, i * 1200 + 300));
    timer = setTimeout(() => { sc = (sc + 1) % CHAT.length; run(); }, 5600);
  }

  /** a legmagasabb jelenet magasságára méretezi a hírfolyamot, így nem ugrál az elrendezés */
  function fit() {
    const probe = document.createElement('div');
    probe.style.cssText = `position:absolute;visibility:hidden;top:-9999px;display:flow-root;width:${feed.clientWidth}px`;
    feed.parentNode.insertBefore(probe, feed);
    let max = 0;
    CHAT.forEach((s) => { probe.innerHTML = s.msgs.map(bubble).join(''); max = Math.max(max, probe.offsetHeight); });
    probe.remove(); feed.style.minHeight = (max + 2) + 'px';
  }

  const mq = matchMedia('(max-width:900px)');
  const place = () => { (mq.matches ? $('#mw') : home).appendChild(mock); fit(); };
  mq.addEventListener('change', place);
  let rz; addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(fit, 120); });
  document.fonts?.ready.then(fit);
  document.addEventListener('langchange', () => { run(); fit(); });
  place(); run();
}
