export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const prefersReducedMotion = () => matchMedia('(prefers-reduced-motion:reduce)').matches;
export const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const raf = () => new Promise((r) => requestAnimationFrame(() => r()));
/** Kerekítés egészre "half-even" módon (mint a Python .0f) – a generált SVG-k pontos egyezéséhez */
export const n0 = (v) => { const f = Math.floor(v), r = v - f; return String(r < 0.5 ? f : r > 0.5 ? f + 1 : (f % 2 === 0 ? f : f + 1)); };
