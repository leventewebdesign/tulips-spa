/** Illusztrációk (SVG). A főoldal hero- és táj-grafikáját klónozzuk, a hidat generáljuk – így nincs duplikált markup. */
import { $, n0 } from './dom.js';

export function heroScene(cls = 'art') {
  const s = $('.hero .scn').cloneNode(true);
  s.setAttribute('class', cls); s.removeAttribute('style');
  return s.outerHTML;
}

export function plainsScene() {
  const s = $('.why .pl.d').cloneNode(true);
  s.setAttribute('class', 'art'); s.setAttribute('preserveAspectRatio', 'xMidYMax slice');
  return s.outerHTML;
}

export function bridgeScene() {
  const DK = 282;
  const ch = [[[330, 160], [485, 300], [640, 160]], [[130, 276], [235, 206], [330, 160]], [[640, 160], [745, 206], [840, 276]]];
  const q = (t, a, c, b) => { const u = 1 - t; return [u * u * a[0] + 2 * u * t * c[0] + t * t * b[0], u * u * a[1] + 2 * u * t * c[1] + t * t * b[1]]; };
  let hangers = '';
  for (const [a, c, b] of ch) {
    const n = Math.floor(Math.abs(b[0] - a[0]) / 15);
    for (let i = 1; i < n; i++) { const [x, y] = q(i / n, a, c, b); hangers += `M${n0(x)} ${n0(y)}V${DK}`; }
  }
  let lamps = '', refl = '', stars = '', wins = '';
  for (let x = 150; x < 840; x += 22) lamps += `<circle class="ts" cx="${x}" cy="${DK - 3}" r="2" style="animation-delay:-${((x % 7) * 0.4).toFixed(1)}s"/>`;
  for (let x = 150; x < 840; x += 44) refl += `<circle cx="${x}" cy="${DK + 2 * (330 - DK) + 8}" r="2"/>`;
  for (let x = 1; x < 26; x++) stars += `<circle class="ts" cx="${(x * 97) % 880 + 10}" cy="${(x * 53) % 150 + 10}" r="${1 + (x % 2) * 0.5}" style="animation-delay:-${x % 5}s"/>`;
  for (let x = 134; x < 410; x += 22) for (const y of [200, 216]) wins += `<rect class="ts" x="${x}" y="${y}" width="4" height="7" rx="1" style="animation-delay:-${(x + y) % 6}s"/>`;
  return `<svg class="art" viewBox="0 0 900 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><rect width="900" height="400" fill="url(#nb)"/><g fill="#fff">${stars}</g><circle cx="770" cy="86" r="64" fill="#ffd9a0" opacity=".12"/><circle cx="770" cy="86" r="22" fill="#ffe7b8"/>
<path d="M0 330V252Q110 206 250 218Q380 196 500 236L640 330z" fill="#0b2150"/><g fill="#0b2150"><rect x="120" y="190" width="300" height="46"/><rect x="112" y="170" width="34" height="66"/><rect x="394" y="170" width="34" height="66"/><path d="M236 190Q266 140 296 190z"/></g>
<g fill="#ffd98a" opacity=".9">${wins}</g>
<g fill="#0b2150" stroke="#E3B867" stroke-width="1.6"><rect x="306" y="152" width="48" height="180"/><rect x="616" y="152" width="48" height="180"/><rect x="299" y="146" width="62" height="8"/><rect x="609" y="146" width="62" height="8"/></g>
<g fill="none" stroke="#E3B867" stroke-width="1.6"><path d="M319 ${DK}V268a11 11 0 0 1 22 0V${DK}M629 ${DK}V268a11 11 0 0 1 22 0V${DK}"/><path stroke-width="2.2" d="M330 160Q485 300 640 160M130 276Q235 206 330 160M640 160Q745 206 840 276M120 ${DK}H850M120 ${DK + 8}H850"/><path stroke-opacity=".38" stroke-width="1" d="${hangers}"/></g>
<g fill="#ffd98a">${lamps}</g><rect y="330" width="900" height="70" fill="url(#nw)"/><g fill="#ffd98a" opacity=".35">${refl}</g>
<path class="shm" d="M120 346h160M300 360h220M540 352h200M180 376h180M600 378h200" stroke="#E3B867" stroke-opacity=".3" stroke-width="2" stroke-linecap="round" fill="none"/></svg>`;
}
