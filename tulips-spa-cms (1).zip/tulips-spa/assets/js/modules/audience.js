/** "Hazai vállalkozásoknak / Nemzetközi partnereknek" váltó + animált illusztráció. */
import { $, $$, prefersReducedMotion } from './dom.js';
import { t } from './i18n.js';
import { AUDIENCE } from '../data/audience.js';
import { VZ } from '../data/viz.js';

export function initAudience() {
  const viz = $('#viz'), btns = $$('.tg button');
  let ai = 0;
  function render(i, { focus = false } = {}) {
    ai = i; const a = AUDIENCE[i];
    viz.innerHTML = VZ[i]();
    if (prefersReducedMotion()) viz.firstChild.pauseAnimations?.();
    $('#at').textContent = t(a.title);
    $('#al').innerHTML = a.items.map((x) => `<li><span class="ic">${x.icon}</span><div><b>${t(x.title)}</b><span>${t(x.desc)}</span></div></li>`).join('');
    btns.forEach((b, j) => { b.setAttribute('aria-selected', String(j === i)); b.tabIndex = j === i ? 0 : -1; });
    if (focus) btns[i].focus();
  }
  btns.forEach((b) => b.addEventListener('click', () => render(+b.dataset.a)));
  btns[0].parentElement.addEventListener('keydown', (e) => {
    let i = ai;
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') i = (ai + 1) % btns.length;
    else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') i = (ai - 1 + btns.length) % btns.length;
    else return;
    e.preventDefault(); render(i, { focus: true });
  });
  document.addEventListener('langchange', () => render(ai));
  render(0);
}
