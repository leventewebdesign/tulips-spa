/** Szolgáltatásválasztó (tablist) – nyilak, Home/End, roving tabindex; "Ajánlatot kérek" → űrlap előválasztás. */
import { $, $$ } from './dom.js';
import { t } from './i18n.js';
import { SERVICES } from '../data/services.js';
import { navigate } from './router.js';
import { pickOption } from './form.js';

export function initServices() {
  const tabs = $('#tabs'), panel = $('#panel');
  let ti = 0;
  const title = (s) => t(`services.${s.code}.title`);

  function renderTabs() {
    tabs.innerHTML = SERVICES.map((s, i) => `<button class="tab" role="tab" id="tab-${i}" aria-selected="${i === ti}" aria-controls="panel" tabindex="${i === ti ? 0 : -1}" data-i="${i}">${title(s)}<small>${s.code}</small></button>`).join('');
  }
  function show(i, { focus = false } = {}) {
    ti = i; const s = SERVICES[i];
    $$('.tab', tabs).forEach((b, j) => { b.setAttribute('aria-selected', String(j === i)); b.tabIndex = j === i ? 0 : -1; });
    if (focus) $(`#tab-${i}`).focus();
    panel.setAttribute('aria-labelledby', `tab-${i}`);
    panel.innerHTML = `<span class="code">${t('label.code')} ${s.code}</span><h3>${title(s)}</h3><p>${t(`services.${s.code}.desc`)}</p><ul>${[1, 2, 3].map((n) => `<li>${t(`services.${s.code}.p${n}`)}</li>`).join('')}</ul><button class="btn p" data-pre="${i + 2}">${t('cta.request')}</button>`;
  }
  tabs.addEventListener('click', (e) => { const b = e.target.closest('.tab'); if (b) show(+b.dataset.i); });
  tabs.addEventListener('keydown', (e) => {
    const n = SERVICES.length; let i = ti;
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') i = (ti + 1) % n;
    else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') i = (ti - 1 + n) % n;
    else if (e.key === 'Home') i = 0; else if (e.key === 'End') i = n - 1; else return;
    e.preventDefault(); show(i, { focus: true });
  });
  panel.addEventListener('click', (e) => {
    const b = e.target.closest('[data-pre]'); if (!b) return;
    pickOption(+b.dataset.pre); navigate('/kapcsolat');
  });
  document.addEventListener('langchange', () => { renderTabs(); show(ti); });
  renderTabs(); show(0);
}
