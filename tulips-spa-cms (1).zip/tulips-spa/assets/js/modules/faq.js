/** GYIK modul: adatvezérelt (assets/data/faq.json) – főoldali előnézet + teljes GYIK oldal élő kereséssel. */
import { $, esc } from './dom.js';
import { t } from './i18n.js';
import { BASE } from '../config.js';
import { pageHero, ctaBand } from './components.js';
import { plainsScene } from './scenes.js';
import { observeReveal } from './reveal.js';

let items = null;
export async function loadFaq() {
  if (!items) items = await (await fetch(`${BASE}assets/data/faq.json`)).json();
  return items;
}
export const faqHtml = (list, openIndex = 0) => list.map((f, i) => `<details class="q"${i === openIndex ? ' open' : ''}><summary>${esc(t(f.q))}</summary><p>${esc(t(f.a))}</p></details>`).join('');

export async function renderPreview() {
  const box = $('#faq-preview'); if (!box) return;
  box.innerHTML = faqHtml((await loadFaq()).filter((f) => f.home));
}

export async function render(el) {
  const list = await loadFaq();
  el.innerHTML = pageHero({ title: t('faq.h1'), sub: t('faq.sub'), scene: plainsScene() })
    + `<section class="sec"><div class="w" style="max-width:860px"><div class="faq-tools"><input id="fs" type="search" placeholder="${esc(t('ui.search'))}" aria-label="${esc(t('ui.search'))}" aria-controls="faq-list nores"></div><div class="fq" id="faq-list">${faqHtml(list)}</div><div class="nores" id="nores" role="status" aria-live="polite">${esc(t('ui.nores'))}</div></div></section>`
    + ctaBand('ui.noans');
  const input = $('#fs', el), qs = [...el.querySelectorAll('.fq .q')], none = $('#nores', el);
  input.addEventListener('input', () => {
    const v = input.value.trim().toLowerCase(); let c = 0;
    qs.forEach((q) => { const m = !v || q.textContent.toLowerCase().includes(v); q.hidden = !m; if (m) c++; });
    none.style.display = c ? 'none' : 'block';
  });
  observeReveal(el);
}
export const rerender = () => render($('#view-faq'));
