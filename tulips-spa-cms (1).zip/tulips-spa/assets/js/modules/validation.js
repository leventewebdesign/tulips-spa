/** Űrlap-validáció: kötelező mezők + e-mail formátum; aria-invalid beállítása. */
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateForm(form) {
  const invalid = [];
  form.querySelectorAll('[required]').forEach((f) => {
    const v = f.value.trim();
    const bad = !v || (f.type === 'email' && !EMAIL.test(v));
    f.setAttribute('aria-invalid', String(bad));
    if (bad) invalid.push(f);
  });
  return { valid: invalid.length === 0, invalid };
}

export function clearInvalid(form) {
  form.querySelectorAll('[aria-invalid]').forEach((f) => f.removeAttribute('aria-invalid'));
}
