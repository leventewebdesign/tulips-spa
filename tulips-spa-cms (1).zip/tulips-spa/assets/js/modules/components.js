/** Közös HTML-építőelemek az aloldalakhoz (a megjelenés megegyezik az eredeti aloldalakéval). */
import { esc } from './dom.js';
import { t } from './i18n.js';

export const pageHero = ({ title, sub, scene, crumb }) => `<section class="pg-hero">${scene}<div class="w"><nav class="crumbs" aria-label="${esc(t('a11y.breadcrumb'))}"><a href="/">${esc(t('ui.home'))}</a><span aria-hidden="true">/</span><span aria-current="page">${esc(crumb || title)}</span></nav><h1 id="view-title">${esc(title)}</h1><p class="sub">${esc(sub)}</p><a class="back" href="/"><i class="arr" aria-hidden="true">←</i><span>${esc(t('ui.back'))}</span></a></div></section>`;

export const ctaBand = (headKey = 'ui.cta') => `<section class="cta-band"><div class="w"><div class="cb rv"><div><h2>${esc(t(headKey))}</h2><p>${esc(t('contact.lead'))}</p></div><a class="btn p" href="/kapcsolat">${esc(t('hero.cta1'))}</a></div></div></section>`;
