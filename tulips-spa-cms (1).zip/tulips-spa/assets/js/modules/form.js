/** Kapcsolati űrlap: szolgáltatás-lista, gyorsválasztó chipek, validáció, EmailJS küldés (értesítő a tulajdonosnak + automatikus visszaigazolás a látogatónak). */
import { $, $$, esc } from './dom.js';
import { t } from './i18n.js';
import { SERVICES } from '../data/services.js';
import { CHIPS } from '../data/chat.js';
import { validateForm, clearInvalid } from './validation.js';

let pi = 0;
const options = () => [t('form.opt.unsure'), t('form.opt.custom'), ...SERVICES.map((s) => `${s.code} ${t(`services.${s.code}.title`)}`)];

export function pickOption(i) {
  pi = i;
  const sel = $('#sel'); if (sel) sel.value = i;
  $$('#chips button').forEach((b) => { const on = +b.dataset.o === i; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
}

export function initForm() {
  const f = $('#contact-form'), sel = $('#sel'), chips = $('#chips'), ok = $('#form-status'), btn = $('#submit-btn'), svc = $('#service-name');
  const render = () => {
    sel.innerHTML = options().map((o, i) => `<option value="${i}">${esc(o)}</option>`).join('');
    sel.value = pi;
    chips.innerHTML = CHIPS.map((c) => `<button type="button" data-o="${c.opt}" aria-pressed="${c.opt === pi}"${c.opt === pi ? ' class="on"' : ''}>${t(c.key)}</button>`).join('');
  };
  const status = (type, key) => { ok.className = 'is-' + type; ok.textContent = t(key); };

  chips.addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) pickOption(+b.dataset.o); });
  sel.addEventListener('change', (e) => pickOption(+e.target.value));
  f.addEventListener('input', (e) => { if (e.target.hasAttribute('aria-invalid')) e.target.removeAttribute('aria-invalid'); });

  f.addEventListener('submit', (e) => {
    e.preventDefault();
    const { valid, invalid } = validateForm(f);
    if (!valid) { status('error', 'form.error'); invalid[0].focus(); return; }
    clearInvalid(f);
    if (typeof emailjs === 'undefined') { status('error', 'form.fail'); return; }

    svc.value = options()[+sel.value];               // a szolgáltatás szövege (nem a sorszáma) menjen az e-mailbe
    const label = btn.textContent;
    btn.textContent = t('form.sending'); btn.disabled = true; ok.className = ''; ok.textContent = '';
    const done = () => { btn.textContent = label; btn.disabled = false; };

    // 1. Értesítő levél a tulajdonosnak
    emailjs.sendForm('service_eyhexit', 'template_4btqadc', f)
      .then(() => {
        // 2. Automatikus visszaigazolás a kitöltőnek (hibája nem érinti a már elment értesítőt)
        emailjs.sendForm('service_eyhexit', 'template_y2fc5wu', f)
          .catch((err) => console.error('EmailJS visszaigazolás hiba:', err));
        done(); status('success', 'form.success'); f.reset(); pickOption(0);
      })
      .catch((err) => { console.error('EmailJS hiba:', err); done(); status('error', 'form.fail'); });
  });
  document.addEventListener('langchange', () => { render(); ok.className = ''; ok.textContent = ''; });
  render();
}
