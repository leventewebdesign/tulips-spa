/** Fejléc: görgetés (sc/hide), mobilmenü (aria-expanded, inert, Esc), aktuális oldal jelölése (aria-current). */
import { $, $$ } from './dom.js';
import { t } from './i18n.js';
import { toPath } from './router.js';

export function initNav() {
  const hd = $('header'), bg = $('#bg'), mm = $('#mm');
  let ly = 0, tick = false;

  const setMenu = (open, { returnFocus = false } = {}) => {
    mm.classList.toggle('open', open);
    mm.toggleAttribute('inert', !open);
    bg.setAttribute('aria-expanded', String(open));
    bg.setAttribute('aria-label', t(open ? 'nav.menu.close' : 'nav.menu.open'));
    if (!open && returnFocus) bg.focus();
  };
  setMenu(false);

  bg.addEventListener('click', () => setMenu(!mm.classList.contains('open')));
  mm.addEventListener('click', (e) => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('click', (e) => { if (!e.target.closest('header')) setMenu(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && mm.classList.contains('open')) setMenu(false, { returnFocus: true }); });
  matchMedia('(min-width:901px)').addEventListener('change', () => setMenu(false));
  document.addEventListener('langchange', () => setMenu(mm.classList.contains('open')));

  addEventListener('scroll', () => {
    if (tick) return; tick = true;
    requestAnimationFrame(() => {
      const y = scrollY;
      hd.classList.toggle('sc', y > 30);
      hd.classList.toggle('hide', y > ly && y > 160 && !mm.classList.contains('open'));
      ly = y; document.dispatchEvent(new Event('tg:scroll')); tick = false;
    });
  }, { passive: true });

  // aktuális oldal jelölése a menüben és a láblécben
  const mark = () => {
    const cur = toPath();
    $$('header a[href], footer a[href]').forEach((a) => {
      const u = new URL(a.href, location.href);
      if (u.origin === location.origin && toPath(u) === cur && !a.matches('.logo')) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
  };
  document.addEventListener('routechange', mark);
  mark();
}
