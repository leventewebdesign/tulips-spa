/**
 * Teljesítmény: a képernyőn kívüli, animált jelenetek animációit szüneteltetjük (class "off"),
 * így görgetés közben a böngészőnek nem kell a nem látható SVG-ket újrafestenie.
 * Az elemek: hero, "Miért Magyarország" táj, kapcsolat-szekció, aloldal-hero.
 */
const SEL = '.hero, .why, .ct, .pg-hero, .art-img';

export function initPerf(root = document) {
  if (!('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver((es) => es.forEach((e) => e.target.classList.toggle('off', !e.isIntersecting)), { rootMargin: '120px 0px' });
  root.querySelectorAll(SEL).forEach((el) => { if (!el.dataset.perf) { el.dataset.perf = '1'; io.observe(el); } });
  // görgetés közben szünetelnek a jelenet-animációk (a böngésző nem fest újra minden képkockán), megállva folytatódnak
  let idle, on = false; const h = document.documentElement;
  addEventListener('scroll', () => {
    if (!on) { on = true; h.classList.add('scrolling'); }
    clearTimeout(idle); idle = setTimeout(() => { on = false; h.classList.remove('scrolling'); }, 140);
  }, { passive: true });
  // lapfül háttérben: minden animáció áll
  document.addEventListener('visibilitychange', () => document.documentElement.classList.toggle('bg-tab', document.hidden));
}
