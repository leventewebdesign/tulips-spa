/** "Miért Magyarország" oldal: adókulcs-kártya, animált távolságdiagram, érvek. */
import { $, esc, n0 } from './dom.js';
import { t } from './i18n.js';
import { pageHero, ctaBand } from './components.js';
import { heroScene, plainsScene, bridgeScene } from './scenes.js';
import { observeReveal } from './reveal.js';
import { initTaxCounters } from './counter.js';
import { CITIES } from '../data/cities.js';

function radial() {
  const cx = 350, cy = 262; let sp = '', pts = '';
  CITIES.forEach((c, k) => {
    const r = 40 + c.km * 0.33, rad = c.bearing * Math.PI / 180;
    const x = cx + Math.sin(rad) * r, y = cy - Math.cos(rad) * r, L = Math.hypot(x - cx, y - cy);
    sp += `<line class="spoke" x1="${cx}" y1="${cy}" x2="${n0(x)}" y2="${n0(y)}" style="--l:${n0(L)};--k:${k}"/>`;
    pts += `<g class="pt" style="--k:${k}"><circle cx="${n0(x)}" cy="${n0(y)}" r="8" fill="#12388A"/><circle cx="${n0(x)}" cy="${n0(y)}" r="3" fill="#fff"/><text x="${n0(x)}" y="${n0(y - 14)}" text-anchor="middle">${esc(t(c.key))}</text><text class="km" x="${n0(x)}" y="${n0(y + 26)}" text-anchor="middle">${c.km}</text></g>`;
  });
  return `<svg viewBox="150 55 480 400" role="img" aria-label="${esc(t('ui.km'))}">${sp}${pts}<circle class="hub" cx="${cx}" cy="${cy}" r="16" fill="#E10040"/><circle cx="${cx}" cy="${cy}" r="6" fill="#fff"/><text x="${cx}" y="${cy + 40}" text-anchor="middle" style="font-weight:700">${esc(t('city.bud'))}</text></svg>`;
}

export async function render(el) {
  const cards = [2, 3, 4].map((j) => `<div class="card rv"><h3>${esc(t(`why.s${j}.h`))}</h3><p>${esc(t(`why.s${j}.p`))}</p></div>`).join('');
  const pts = [1, 2, 3, 4].map((j) => `<li>${esc(t(`why.p${j}`))}</li>`).join('');
  el.innerHTML = pageHero({ title: t('why.h1'), sub: t('why.lead'), scene: heroScene('art') })
    + `<section class="sec"><div class="w"><div class="why-top"><div class="nine rv"><div class="n" data-tax>9%</div><div class="tb"><i data-tax-bar></i></div><div><p>${esc(t('why.tax'))}</p><p style="font-size:.88rem;opacity:.85;margin-top:12px">${esc(t('why.note'))}</p></div></div>`
    + `<div class="dist rv"><h3 style="margin:0 0 4px;font-size:1.5rem">${esc(t('why.s1.h'))}</h3><p style="margin:0 0 6px;color:#3d4560">${esc(t('why.s1.p'))}</p>${radial()}<p class="cap">${esc(t('ui.km'))}</p></div></div></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><div class="trio">${cards}</div></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><div class="split"><div class="art-img rv">${bridgeScene()}</div><div class="rv"><h2>${esc(t('why.s5.h'))}</h2><p style="color:#3d4560;font-size:1.1rem">${esc(t('why.s5.p'))}</p></div></div></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><div class="art-img rv" style="aspect-ratio:16/4.2;border-radius:6px;background:linear-gradient(180deg,#06205c,#0e4a8c)">${plainsScene()}</div></div></section>`
    + `<section class="sec" style="padding-top:8px"><div class="w"><div class="rv"><h2>${esc(t('why.s6.h'))}</h2><ul class="pts">${pts}</ul></div></div></section>`
    + ctaBand();
  observeReveal(el); initTaxCounters(el);
}
export const update = async () => {};
export const rerender = () => render($('#view-why'));
