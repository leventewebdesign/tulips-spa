/**
 * Görgetésfüggő háttérszínjáték + hero parallax – teljesítményre hangolva:
 *  - minden a nav.js egyetlen rAF-hoz kötött 'tg:scroll' eseményén fut (nincs külön scroll-listener)
 *  - a színek csak akkor íródnak, ha a görgetési arány legalább 1/48 lépést változott (nem minden képkockán)
 *  - a foltok színe CSS-változó (--fxc), nincs inline background-írás és nincs blur-szűrő
 *  - érintőképernyőn / kis kijelzőn nincs parallax (a mobilböngésző címsor-átméretezése miatt rángatna)
 */
import { $, prefersReducedMotion } from './dom.js';

const P1 = ['#F2F5FB', '#F4F6FC', '#F1F5FB', '#F5F6FB', '#F2F5FB', '#F1F4FA'];
const P2 = ['#DFE7F6', '#E4E9F7', '#DCE6F7', '#E5E8F6', '#DFE7F6', '#DBE5F5'];
const PD = ['#1A0A0F', '#2B0713', '#1E0A10', '#14080C'];
const PA = ['#E10040', '#D6204F', '#E10040', '#C8103F'];
const PB = ['#2F5BE0', '#1E4DB7', '#3B6FE0', '#2F5BE0'];

const hex = (c) => [1, 3, 5].map((i) => parseInt(c.substr(i, 2), 16));
const mix = (a, b, t) => { const x = hex(a), y = hex(b); return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
const pal = (P, p) => { const x = p * (P.length - 1), i = Math.min(Math.floor(x), P.length - 2); return mix(P[i], P[i + 1], x - i); };

export function initFx() {
  const f1 = $('.f1'), f2 = $('.f2'), root = document.documentElement.style;
  const coarse = matchMedia('(max-width:900px), (hover:none)');
  let lastStep = -1;

  const update = () => {
    const m = document.documentElement.scrollHeight - innerHeight;
    const p = m > 0 ? Math.min(Math.max(scrollY / m, 0), 1) : 0;
    const step = Math.round(p * 48);
    if (step !== lastStep) {
      lastStep = step;
      const q = step / 48;
      root.setProperty('--c1', pal(P1, q)); root.setProperty('--c2', pal(P2, q)); root.setProperty('--dk', pal(PD, q));
      f1.style.setProperty('--fxc', pal(PA, q)); f2.style.setProperty('--fxc', pal(PB, q));
    }
    if (!coarse.matches) {
      f1.style.transform = `translate3d(${(p * 70).toFixed(1)}vw,${(p * 50).toFixed(1)}vh,0) scale(${(1 + p * 0.4).toFixed(3)})`;
      f2.style.transform = `translate3d(${(-p * 60).toFixed(1)}vw,${(-p * 45).toFixed(1)}vh,0) scale(${(1.3 - p * 0.4).toFixed(3)})`;
    }
  };
  addEventListener('resize', () => { lastStep = -1; update(); }, { passive: true });
  document.addEventListener('tg:scroll', update);
  update();

  // Hero parallax: csak asztali, mutatóeszközös nézetben, és csak amíg a hero látszik
  const hero = $('.hero .scn');
  const native = window.CSS?.supports?.('animation-timeline: scroll()');   // ha a böngésző tudja, a CSS végzi a parallaxot
  if (hero && !native && !prefersReducedMotion()) {
    document.addEventListener('tg:scroll', () => {
      if (coarse.matches) { if (hero.style.transform) hero.style.transform = ''; return; }
      const y = scrollY;
      if (y < innerHeight * 1.3) hero.style.transform = `translate3d(0,${(y * 0.12).toFixed(1)}px,0)`;
    });
  }
  return update;
}
