/** Görgetésre megjelenő elemek (.rv → .v) és számlálók ([data-n]). */
const io = new IntersectionObserver((es) => es.forEach((e) => {
  if (!e.isIntersecting) return;
  e.target.classList.add('v'); io.unobserve(e.target);
}), { threshold: 0.15 });

const co = new IntersectionObserver((es) => es.forEach((e) => {
  if (!e.isIntersecting) return;
  const el = e.target, n = +el.dataset.n, s = el.dataset.s || '';
  let t0;
  const step = (t) => { t0 = t0 || t; const p = Math.min((t - t0) / 1400, 1); el.textContent = Math.round(n * (1 - Math.pow(1 - p, 3))) + s; if (p < 1) requestAnimationFrame(step); };
  requestAnimationFrame(step); co.unobserve(el);
}), { threshold: 0.6 });

export function observeReveal(root = document) {
  root.querySelectorAll('.rv:not(.v)').forEach((x) => io.observe(x));
  root.querySelectorAll('[data-n]').forEach((x) => co.observe(x));
}
