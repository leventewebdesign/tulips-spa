/** Adatvédelem / ÁSZF: egyelőre "Hamarosan" oldal – a szöveg helye a #legal-content blokk. */
import { $, esc } from './dom.js';
import { t } from './i18n.js';
import { pageHero } from './components.js';
import { bridgeScene, plainsScene } from './scenes.js';
import { observeReveal } from './reveal.js';

const DOC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg>';
const PAGES = {
  privacy: { h: 'ui.privacy', sub: 'leg.p.sub', scene: bridgeScene },
  terms: { h: 'ui.terms', sub: 'leg.t.sub', scene: plainsScene },
};

export const make = (kind) => ({
  async render(el) {
    const p = PAGES[kind];
    el.innerHTML = pageHero({ title: t(p.h), sub: t(p.sub), scene: p.scene() })
      + `<section class="sec"><div class="w"><div class="legal-soon rv"><div class="ico">${DOC}</div><h2>${esc(t('ui.soon.h'))}</h2><p>${esc(t('ui.soon.p'))}</p><a class="btn p" href="/kapcsolat">${esc(t('hero.cta1'))}</a><div class="skl" aria-hidden="true"><i></i><i></i><i></i><i></i></div></div><div class="legal" id="legal-content"><!-- IDE KERÜL A SZÖVEG / CONTENT GOES HERE --></div></div></section>`;
    observeReveal(el);
  },
  update: async () => {},
  rerender() { return this.render($(`#view-${kind}`)); },
});
