/** Oldalváltó "függöny" animáció (CSS: #pt, html.pt-out / html.pt-in). */
import { prefersReducedMotion, sleep } from './dom.js';

export async function withCurtain(change) {
  const h = document.documentElement;
  if (prefersReducedMotion()) { await change(); return; }
  h.classList.add('pt-out');
  await sleep(320);
  await change();
  h.classList.remove('pt-out');
  h.classList.add('pt-in');
  setTimeout(() => h.classList.remove('pt-in'), 700);
}
