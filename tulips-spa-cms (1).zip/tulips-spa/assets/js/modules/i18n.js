/**
 * Egyszerű i18n: JSON nyelvi fájlok (assets/i18n/<kód>.json) + t() fordítófüggvény.
 *  - t('nav.about')                  → szöveg a kiválasztott nyelven (hiányzó kulcs: en → hu → maga a kulcs)
 *  - t('x.hello', { name: 'Éva' })   → "{name}" helyettesítés
 *  - apply(gyökér)                   → [data-i18n="kulcs"] és [data-i18n-attr="attr:kulcs;attr2:kulcs2"] elemek frissítése
 */
import { BASE, DEFAULT_LANG, LANGS, FONTS } from './../config.js';

const STORE_KEY = 'tg-lang';
const packs = {};
let lang = DEFAULT_LANG;

const flatten = (o, p = '', out = {}) => {
  for (const k in o) {
    const v = o[k], key = p ? p + '.' + k : k;
    v && typeof v === 'object' ? flatten(v, key, out) : (out[key] = v);
  }
  return out;
};

async function load(code) {
  if (packs[code]) return packs[code];
  try {
    const r = await fetch(`${BASE}assets/i18n/${code}.json`);
    if (!r.ok) throw new Error(r.status);
    packs[code] = flatten(await r.json());
  } catch (e) {
    console.warn('[i18n] nem sikerült betölteni:', code, e);
    packs[code] = {};
  }
  return packs[code];
}

export const getLang = () => lang;
export const meta = (code = lang) => LANGS.find((l) => l.code === code) || LANGS[0];

export function t(key, params) {
  let s = packs[lang]?.[key] ?? packs.en?.[key] ?? packs[DEFAULT_LANG]?.[key] ?? key;
  if (params) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in params ? params[k] : m));
  return s;
}

export function apply(root = document) {
  root.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll('[data-i18n-attr]').forEach((el) => {
    el.dataset.i18nAttr.split(';').forEach((pair) => {
      const [attr, key] = pair.split(':');
      if (attr && key) el.setAttribute(attr.trim(), t(key.trim()));
    });
  });
}

function ensureFonts(code) {
  const href = FONTS[code];
  if (!href || document.querySelector(`link[data-font="${code}"]`)) return;
  const l = document.createElement('link');
  l.rel = 'stylesheet'; l.href = href; l.dataset.font = code;
  document.head.appendChild(l);
}

export async function setLang(code, { persist = true } = {}) {
  if (!LANGS.some((l) => l.code === code)) code = DEFAULT_LANG;
  await Promise.all([load(DEFAULT_LANG), load('en'), load(code)]);
  lang = code;
  const m = meta(code), d = document.documentElement;
  d.lang = code; d.dir = m.dir; ensureFonts(code);
  if (persist) { try { localStorage.setItem(STORE_KEY, code); } catch (e) { /* privát mód */ } }
  apply();
  document.dispatchEvent(new CustomEvent('langchange', { detail: { lang: code } }));
}

export async function initI18n() {
  let code = DEFAULT_LANG;
  try {
    const s = new URLSearchParams(location.search).get('lang') || localStorage.getItem(STORE_KEY);
    if (LANGS.some((l) => l.code === s)) code = s;
    if (!new URLSearchParams(location.search).get('lang') && /business-services-budapest\/?$/.test(location.pathname)) code = 'en';
  } catch (e) { /* nincs tárhely */ }
  await setLang(code, { persist: false });
}
