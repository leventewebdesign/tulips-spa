/** "Tulips munkatér" demó-jelenetek és az űrlap gyorsválasztói. Szövegek: <key>.name / <key>.text / <key>.sub */
export const CHAT = [
  { key: 'chat.s1', msgs: [{ key: 'chat.s1.m1', ok: true }, { key: 'chat.s1.m2' }, { key: 'chat.s1.m3', ok: true }] },
  { key: 'chat.s2', msgs: [{ key: 'chat.s2.m1' }, { key: 'chat.s2.m2', ok: true }, { key: 'chat.s2.m3', ok: true }] },
  { key: 'chat.s3', msgs: [{ key: 'chat.s3.m1' }, { key: 'chat.s3.m2', ok: true }, { key: 'chat.s3.m3', ok: true }] },
];
/** opt = a legördülő lista sorszáma (0: nem tudom, 1: egyedi, 2..8: szolgáltatások) */
export const CHIPS = [
  { key: 'form.chip.management', opt: 2 },
  { key: 'form.chip.pr', opt: 3 },
  { key: 'form.chip.travel', opt: 5 },
  { key: 'form.chip.admin', opt: 6 },
  { key: 'form.chip.unsure', opt: 0 },
];
