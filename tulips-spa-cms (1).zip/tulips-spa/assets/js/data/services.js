/** Szolgáltatások (TEÁOR/NACE kódok). Szövegek: services.<kód>.title|desc|p1|p2|p3 az i18n JSON-ban. */
export const SERVICES = ['7010', '7021', '7911', '7912', '8211', '8299', '8413'].map((code) => ({ code }));
