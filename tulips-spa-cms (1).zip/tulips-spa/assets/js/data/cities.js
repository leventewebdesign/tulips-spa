/** Távolságdiagram (Miért Magyarország oldal): közelítő közúti távolság Budapesttől (km) és irány (fok). */
export const CITIES = [
  { key: 'city.vie', km: 245, bearing: 280 },
  { key: 'city.bts', km: 200, bearing: 330 },
  { key: 'city.prg', km: 530, bearing: 322 },
  { key: 'city.zag', km: 350, bearing: 238 },
  { key: 'city.beg', km: 380, bearing: 160 },
  { key: 'city.buc', km: 640, bearing: 108 },
];
