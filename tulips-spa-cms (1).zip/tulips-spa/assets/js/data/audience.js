/** Célközönség-lista ikonokkal. Szövegek: aud.<i>.title, aud.<i>.i<j>.title|desc */
export const AUDIENCE = [
  { title: 'aud.0.title', items: [
    { icon: "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round'><path d='M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/></svg>", title: 'aud.0.i1.title', desc: 'aud.0.i1.desc' },
    { icon: "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round'><path d='M4 10v4h3l7 4V6L7 10z'/><path d='M17.5 9a4 4 0 0 1 0 6'/></svg>", title: 'aud.0.i2.title', desc: 'aud.0.i2.desc' },
    { icon: "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='9'/><path d='M15.5 8.5l-2 5-5 2 2-5z'/></svg>", title: 'aud.0.i3.title', desc: 'aud.0.i3.desc' },
  ] },
  { title: 'aud.1.title', items: [
    { icon: "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round'><path d='M21 16v-2l-8-5V3.5a1.5 1.5 0 0 0-3 0V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5z'/></svg>", title: 'aud.1.i1.title', desc: 'aud.1.i1.desc' },
    { icon: "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round'><circle cx='12' cy='12' r='9'/><path d='M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18'/></svg>", title: 'aud.1.i2.title', desc: 'aud.1.i2.desc' },
    { icon: "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='1.7' stroke-linecap='round' stroke-linejoin='round'><path d='M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z'/><path d='M9 12l2 2 4-4'/></svg>", title: 'aud.1.i3.title', desc: 'aud.1.i3.desc' },
  ] },
];
