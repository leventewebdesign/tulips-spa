/**
 * Központi beállítások: nyelvek, útvonalak (History API), szekció-azonosítók.
 * Új oldal / útvonal felvétele: adj egy sort a ROUTES tömbhöz (és egy nézetet a views/ alatt).
 */
export const BASE = (document.querySelector('meta[name="app-base"]')?.content || '/').replace(/\/?$/, '/'); // <meta name="app-base"> (alapértelmezés: "/")

export const DEFAULT_LANG = 'hu';
export const LANGS = [
  { code: 'hu', label: 'HU', name: 'Magyar', dir: 'ltr' },
  { code: 'en', label: 'EN', name: 'English', dir: 'ltr' },
  { code: 'de', label: 'DE', name: 'Deutsch', dir: 'ltr' },
  { code: 'fr', label: 'FR', name: 'Français', dir: 'ltr' },
  { code: 'ar', label: 'AR', name: 'العربية', dir: 'rtl' },
];

/** Google Fonts: az arab betűtípusok csak arab nyelv kiválasztásakor töltődnek be. */
export const FONTS = {
  ar: 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&family=Noto+Naskh+Arabic:wght@500;600&display=swap',
};

/**
 * Útvonalak. view = melyik "oldal" jelenik meg; anchor = a főoldalon melyik szekcióhoz görgessen.
 * title = i18n kulcs az oldalcímhez.
 */
export const ROUTES = [
  { path: '/', view: 'home', title: 'meta.title.home' },
  { path: '/rolunk', view: 'home', anchor: 'rolunk', title: 'meta.title.home' },
  { path: '/szolgaltatasok', view: 'home', anchor: 'szolgaltatasok', title: 'meta.title.home' },
  { path: '/miert-magyarorszag', view: 'home', anchor: 'magyarorszag', title: 'meta.title.home' },
  { path: '/hirek', view: 'home', anchor: 'hirek', title: 'meta.title.home' },
  { path: '/gyik', view: 'home', anchor: 'gyik', title: 'meta.title.home' },
  { path: '/kapcsolat', view: 'home', anchor: 'kapcsolat', title: 'meta.title.home' },
  { path: '/uzleti-szolgaltatasok-budapest', view: 'services', title: 'meta.title.services', lang: 'hu' },
  { path: '/business-services-budapest', view: 'services', title: 'meta.title.services', lang: 'en' },
  { path: '/blog', view: 'blog', title: 'meta.title.blog' },
  { path: '/blog/:slug', view: 'blog', title: 'meta.title.blog' },
  { path: '/faq', view: 'faq', title: 'meta.title.faq' },
  { path: '/why-hungary', view: 'why', title: 'meta.title.why' },
  { path: '/privacy', view: 'privacy', title: 'meta.title.privacy' },
  { path: '/terms', view: 'terms', title: 'meta.title.terms' },
];

/** A webhely nyilvános címe (kanonikus URL-ekhez, strukturált adatokhoz). Ha más domaint használnak, itt kell átírni. */
export const SITE = 'https://tulipsgroup.hu';
