/** Belépési pont: modulok indítása és a nézetek regisztrálása. */
import { $ } from './modules/dom.js';
import { initI18n } from './modules/i18n.js';
import { initNav } from './modules/nav.js';
import { initLangSwitch } from './modules/lang-switch.js';
import { initFx } from './modules/fx.js';
import { initPerf } from './modules/perf.js';
import { initChat } from './modules/chat.js';
import { initServices } from './modules/services.js';
import { initAudience } from './modules/audience.js';
import { initForm } from './modules/form.js';
import { initTaxCounters } from './modules/counter.js';
import { observeReveal } from './modules/reveal.js';
import { registerView, startRouter } from './modules/router.js';
import { renderNewsCards } from './modules/blog.js';
import { renderPreview } from './modules/faq.js';

/** Lusta nézet: a modul csak az első látogatáskor töltődik be. */
function lazyView(name, loader) {
  const el = $('#view-' + name);
  let mod;
  registerView(name, {
    el,
    async enter(params, route) { mod = mod || await loader(); await mod.render(el, params, route); },
    async update(params, route) { await mod.update?.(el, params, route); },
    rerender(params, route) { mod?.rerender?.(params, route); },
    title: (params) => mod?.title?.(params),
    anchor: (params) => mod?.anchor?.(params),
  });
}

async function boot() {
  await initI18n();
  initFx(); initNav(); initLangSwitch();
  initChat(); initServices(); initAudience(); initForm();
  await Promise.all([renderNewsCards(), renderPreview()]);
  document.addEventListener('langchange', () => { renderNewsCards(); renderPreview(); });
  initTaxCounters(); observeReveal(); initPerf();
  document.addEventListener('routechange', (e) => { if (e.detail.changed) requestAnimationFrame(() => initPerf()); });

  registerView('home', { el: $('#view-home') });
  lazyView('blog', () => import('./modules/blog.js'));
  lazyView('faq', () => import('./modules/faq.js'));
  lazyView('why', () => import('./modules/why.js'));
  lazyView('services', () => import('./modules/services-page.js'));
  lazyView('privacy', async () => (await import('./modules/legal.js')).make('privacy'));
  lazyView('terms', async () => (await import('./modules/legal.js')).make('terms'));
  await startRouter();
  document.documentElement.classList.add('ready');
}
boot();
