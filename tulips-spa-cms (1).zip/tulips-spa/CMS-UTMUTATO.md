# Decap CMS – beüzemelés (egykódos belépéssel)

Az admin felület: `https://<oldal-címe>/admin` – belépés egyetlen kóddal. Domain nélkül is működik a Netlify-os `valami.netlify.app` címen.

## Egyszeri beállítás

1. **GitHub repó**: hozz létre egy (lehet privát) repót, és töltsd fel a `tulips-spa` mappa TARTALMÁT a repó gyökerébe (ahol a `netlify.toml` van).
2. **GitHub-kulcs a CMS-nek**: GitHub → Settings → Developer settings → Personal access tokens → *Fine-grained tokens* → Generate.
   Repository access: *Only select repositories* → csak ez a repó. Permissions: *Contents: Read and write* (a Metadata: Read automatikus).
   Másold ki a kulcsot (`github_pat_…`). Ha a CMS később „nincs jogosultság" hibát ír, használj *classic* tokent `repo` joggal.
3. **Netlify**: Add new site → Import an existing project → a GitHub repó. A build beállításokat a `netlify.toml` adja (build: `python3 build.py && python3 scripts/postbuild.py`, publish: `dist`).
   Site configuration → Environment variables:
   - `ADMIN_CODE` = `01234`
   - `GITHUB_TOKEN` = a 2. lépésben kimásolt kulcs
   Majd Deploys → Trigger deploy.
4. Nyisd meg: `https://<a-netlify-címed>.netlify.app/admin` → *Login with GitHub* → a felugró ablakban írd be a kódot.

## Később, egyedi domainnel
Nincs teendő: a domain Netlify-ban való beállítása után egy újabb deploy automatikusan az új címet írja a CMS konfigjába. (A `scripts/postbuild.py` a Netlify `URL` változójából tölti ki.) Ha a `prerender.py`/`config.js`/sitemap `tulipsgroup.hu` címét is át kell írni, az külön, kézi lépés.

## A kód cseréje
Netlify → Environment variables → `ADMIN_CODE` átírása → új deploy. A kód a kódbázisban sehol sincs.

## Tudnivalók
- **A `01234` nagyon gyenge kód.** Aki ismeri, a CMS-en át módosíthatja az oldalt, és a belépés találgatható (a függvény csak ~1,5 mp-et vár hibás kód után). Éles használatra érdemes legalább 10–12 karakteres kódot választani.
- Minden mentés egy git-commit, a Netlify ~1 percen belül újraépíti az oldalt.
- A CMS a `assets/i18n/*.json` szövegeit szerkeszti (5 nyelv). Az `mail.*` kulcsok (e-mail sablon) és a „listák listája" jellegű `sp.*` mezők (sp.faq, sp.steps, sp.aud, sp.facts) nem jelennek meg; mentéskor érintetlenek maradnak.
- Új cikk / új GYIK-elem felvétele szerkezeti változás (articles.json, faq.json + kulcsok minden nyelvben) – ez fejlesztői feladat.
- Az előrenderelt `/uzleti-szolgaltatasok-budapest` és `/business-services-budapest` HTML-je (keresőbotoknak) csak `python3 prerender.py` futtatása után frissül; a látogatók a JS-sel kirajzolt, mindig friss szöveget látják.
- Új szöveg-kulcs felvétele után: `python3 scripts/gen_cms_config.py`, majd commit.
