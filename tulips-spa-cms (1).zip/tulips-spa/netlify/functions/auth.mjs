// Decap CMS – egykódos belépés.
// A Decap a bejelentkezéskor megnyit egy felugró ablakot erre a címre (/.netlify/functions/auth).
// Itt a szerkesztő beírja a belépőkódot; ha egyezik az ADMIN_CODE környezeti változóval, a függvény átadja
// a CMS-nek a GITHUB_TOKEN-t (egyetlen repóra szűkített hozzáférési kulcs), amivel a CMS menti a módosításokat.
// A kód és a kulcs csak a Netlify környezeti változói között él, a kódban nincs.
import { createHash, timingSafeEqual } from 'node:crypto';

const html = (body, status = 200) =>
  new Response(body, { status, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' } });

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const digest = (s) => createHash('sha256').update(String(s)).digest();
const sameCode = (a, b) => timingSafeEqual(digest(a), digest(b));

const page = (msg = '') => `<!doctype html><html lang="hu"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>Belépés – TULIPS GROUP</title>
<style>
  body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#0f1b3d;color:#fff;margin:0;min-height:100vh;display:grid;place-items:center}
  form{background:#fff;color:#142046;padding:32px;border-radius:14px;width:min(340px,90vw);box-shadow:0 12px 40px #0006}
  h1{font-size:20px;margin:0 0 6px} p{margin:0 0 18px;color:#5b6483;font-size:14px}
  input{width:100%;box-sizing:border-box;padding:12px;font-size:20px;letter-spacing:.2em;text-align:center;border:2px solid #cfd5e8;border-radius:8px}
  button{margin-top:14px;width:100%;padding:12px;font-size:16px;border:0;border-radius:8px;background:#e6174b;color:#fff;cursor:pointer}
  .err{color:#c0102f;font-size:14px;margin-top:10px;min-height:18px}
</style></head><body>
<form method="POST"><h1>Tartalomkezelő</h1><p>Írd be a belépőkódot.</p>
<input name="code" type="password" inputmode="numeric" autocomplete="off" autofocus required aria-label="Belépőkód">
<div class="err" role="alert">${esc(msg)}</div><button type="submit">Belépés</button></form></body></html>`;

const success = (token) => {
  const payload = 'authorization:github:success:' + JSON.stringify({ token, provider: 'github' });
  return html(`<!doctype html><html><body><script>
(function () {
  var msg = ${JSON.stringify(payload).replace(/</g, '\\u003c')};
  window.addEventListener('message', function (e) { window.opener.postMessage(msg, e.origin); }, false);
  window.opener.postMessage('authorizing:github', '*');
})();
</script></body></html>`);
};

export default async (req) => {
  const code = process.env.ADMIN_CODE;
  const token = process.env.GITHUB_TOKEN;
  if (!code || !token) {
    return html(page('Hiányzik a szerver beállítása (ADMIN_CODE / GITHUB_TOKEN a Netlifyban).'), 500);
  }
  if (req.method !== 'POST') return html(page());

  const form = new URLSearchParams(await req.text());
  if (sameCode(form.get('code') || '', code)) return success(token);

  await new Promise((r) => setTimeout(r, 1500)); // lassítja a találgatást
  return html(page('Hibás kód.'), 401);
};
