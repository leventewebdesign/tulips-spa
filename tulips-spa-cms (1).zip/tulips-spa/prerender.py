#!/usr/bin/env python3
"""A szolgáltatás-aloldalak statikus (előrenderelt) HTML-jének elkészítése.

Miért kell? A webhely SPA: a tartalmat a JavaScript rajzolja ki. A keresők egy része és a legtöbb AI-asszisztens-bot
nem futtat JavaScriptet, ezért az új oldal tartalmát (szöveg, GYIK, strukturált adat) kész HTML-ként is előállítjuk:
  /uzleti-szolgaltatasok-budapest/index.html   (magyar)
  /business-services-budapest/index.html       (angol)
Ugyanazt a modult futtatja egy fejetlen böngészőben, mint a látogatók – így a szöveg egyetlen helyen él (assets/i18n/*.json).

Használat (a tartalom vagy az index.html módosítása után, a build.py ELŐTT):
  pip install playwright && playwright install chromium
  python3 prerender.py
"""
import json, re, subprocess, sys, time, threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
SITE = 'https://tulipsgroup.hu'      # ha más a domain, itt és a config.js SITE értékében kell átírni
PAGES = [
    ('hu', 'uzleti-szolgaltatasok-budapest', 'hu_HU'),
    ('en', 'business-services-budapest', 'en_US'),
]

sys.path.insert(0, str(ROOT))
import server  # a fejlesztői SPA-szerver
srv = ThreadingHTTPServer(('127.0.0.1', 0), server.SPAHandler)
port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

esc = lambda s: s.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;')
src = (ROOT / 'index.html').read_text(encoding='utf-8')

with sync_playwright() as p:
    br = p.chromium.launch()
    for lang, slug, loc in PAGES:
        pg = br.new_page(viewport={'width': 1280, 'height': 900})
        pg.route('**/*', lambda r: r.abort() if any(h in r.request.url for h in ('googleapis', 'gstatic', 'jsdelivr')) else r.continue_())
        pg.goto(f'http://127.0.0.1:{port}/{slug}', wait_until='load')
        pg.wait_for_selector('#view-services article.sp-svc', timeout=15000)
        pg.wait_for_timeout(400)
        title = pg.title()
        desc = pg.evaluate("document.querySelector('meta[name=description]').content")
        body = pg.evaluate("document.getElementById('view-services').innerHTML")
        ld = pg.evaluate("document.getElementById('ld-services').textContent")
        pg.close()

        h = src
        h = h.replace('<html lang="hu">', f'<html lang="{lang}">')
        h = re.sub(r'<title>.*?</title>', f'<title>{esc(title)}</title>', h, count=1, flags=re.S)
        h = re.sub(r'(<meta name="description" content=")[^"]*(")', lambda m: m.group(1) + esc(desc) + m.group(2), h, count=1)
        url = f'{SITE}/{slug}'
        h = h.replace('<link rel="canonical" href="https://tulipsgroup.hu/">', f'<link rel="canonical" href="{url}">')
        h = re.sub(r'<meta property="og:title"[^>]*><meta property="og:description"[^>]*>',
                   f'<meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(desc)}">', h, count=1)
        h = h.replace('<meta property="og:url" content="https://tulipsgroup.hu/">', f'<meta property="og:url" content="{url}">')
        h = h.replace('content="hu_HU"', f'content="{loc}"')
        h = h.replace('</head>', f'<script type="application/ld+json" id="ld-services">{ld}</script>\n<noscript><style>.rv{{opacity:1!important;transform:none!important}}</style></noscript>\n</head>', 1)
        # a szolgáltatás-nézet látszik, a főoldali nézet rejtett marad (a JS ezt indításkor úgyis újra beállítja)
        h = h.replace('<div class="view" id="view-home">', '<div class="view" id="view-home" hidden>', 1)
        h = h.replace('<div class="view" id="view-services" hidden></div>', f'<div class="view" id="view-services">{body}</div>', 1)
        out = ROOT / slug
        out.mkdir(exist_ok=True)
        (out / 'index.html').write_text(h, encoding='utf-8')
        print('kész:', out / 'index.html', f'({len(h)//1024} KB)')
    br.close()
srv.shutdown()
