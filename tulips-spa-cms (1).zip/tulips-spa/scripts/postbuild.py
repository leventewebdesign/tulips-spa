#!/usr/bin/env python3
"""A dist/admin/config.yml helyőrzőinek kitöltése a Netlify build környezetéből.

  __SITE_URL__  ← a Netlify által megadott URL (egyedi domain beállítása után automatikusan az lesz)
  __REPO__      ← a REPOSITORY_URL-ből (github.com/<tulaj>/<repo>)
  __BRANCH__    ← BRANCH (a telepített ág)
Felülírható a CMS_SITE_URL, CMS_REPO, CMS_BRANCH környezeti változóval.
"""
import os, re, sys
from pathlib import Path

cfg = Path(__file__).resolve().parent.parent / 'dist/admin/config.yml'
if not cfg.exists():
    sys.exit('dist/admin/config.yml nem található – előbb futtasd a build.py-t')

url = (os.environ.get('CMS_SITE_URL') or os.environ.get('URL') or '').rstrip('/')
repo = os.environ.get('CMS_REPO')
if not repo:
    m = re.search(r'github\.com[/:]([^/\s]+/[^/\s]+?)(?:\.git)?/?$', os.environ.get('REPOSITORY_URL', ''))
    repo = m.group(1) if m else ''
branch = os.environ.get('CMS_BRANCH') or os.environ.get('BRANCH') or 'main'

text = cfg.read_text(encoding='utf-8')
for key, val in (('__SITE_URL__', url), ('__REPO__', repo), ('__BRANCH__', branch)):
    if not val:
        print(f'FIGYELEM: {key} értéke nem állapítható meg (állítsd be a megfelelő CMS_* környezeti változót)', file=sys.stderr)
    else:
        text = text.replace(key, val)
cfg.write_text(text, encoding='utf-8')
print(f'admin/config.yml kész: repo={repo} branch={branch} url={url}')
