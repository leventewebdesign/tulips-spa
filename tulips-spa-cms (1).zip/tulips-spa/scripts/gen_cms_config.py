#!/usr/bin/env python3
"""Az admin/config.yml előállítása az assets/i18n/*.json fájlokból.

Új szöveg-kulcs felvétele után futtasd újra:   python3 scripts/gen_cms_config.py
(A listákból álló listákat – pl. sp.faq, sp.steps – a CMS nem tudja szerkeszteni; ezeket mentéskor érintetlenül hagyja.)
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LANGS = [('hu', 'Magyar'), ('en', 'English'), ('de', 'Deutsch'), ('fr', 'Français'), ('ar', 'العربية')]
SKIP_TOP = {'mail'}   # e-mail sablon: szóközök/sortörések számítanak, nem ügyfélnek való
TOP = {
    'nav': 'Menü', 'hero': 'Nyitóképernyő', 'chat': 'Chat-demó', 'marquee': 'Futószöveg', 'about': 'Rólunk',
    'services': 'Szolgáltatások', 'why': 'Miért Magyarország?', 'stats': 'Számok', 'news': 'Hírek (főoldali kártyák)',
    'faq': 'GYIK', 'contact': 'Kapcsolat', 'form': 'Ajánlatkérő űrlap', 'footer': 'Lábléc', 'aud': 'Célközönség',
    'ui': 'Általános feliratok', 'meta': 'Oldalcímek / SEO', 'label': 'Címkék', 'cta': 'Gombok', 'blog': 'Blog cikkek',
    'city': 'Városok', 'leg': 'Jogi oldalak', 'a11y': 'Akadálymentesség (képernyőolvasó)', 'sp': 'Szolgáltatás-aloldal',
}


def q(s):
    return json.dumps(s, ensure_ascii=False)   # a JSON-sztring egyben érvényes YAML-sztring is


def fields(node, path, depth, out):
    ind = ' ' * depth
    for k, v in node.items():
        full = f'{path}.{k}' if path else k
        if depth == 10 and k in SKIP_TOP:
            continue
        label = TOP.get(k, k) + f' ({k})' if depth == 10 else k
        if isinstance(v, dict):
            out.append(f'{ind}- label: {q(label)}\n{ind}  name: {q(k)}\n{ind}  widget: object\n{ind}  collapsed: true\n{ind}  fields:')
            fields(v, full, depth + 4, out)
        elif isinstance(v, list):
            if all(isinstance(x, str) for x in v):
                out.append(f'{ind}- label: {q(label)}\n{ind}  name: {q(k)}\n{ind}  widget: list\n{ind}  field: {{label: "Elem", name: "elem", widget: text}}')
            # listák listája: kihagyjuk (a CMS mentéskor érintetlenül megőrzi)
        else:
            w = 'text' if (len(v) > 70 or '\n' in v) else 'string'
            out.append(f'{ind}- label: {q(full if depth > 10 else label)}\n{ind}  name: {q(k)}\n{ind}  widget: {w}')


head = '''# Decap CMS – GENERÁLT fájl (scripts/gen_cms_config.py). A három nagybetűs, aláhúzásjeles helyőrzőt
# a scripts/postbuild.py tölti ki a Netlify build közben (a Netlify környezeti változóiból).
backend:
  name: github
  repo: __REPO__
  branch: __BRANCH__
  base_url: __SITE_URL__
  auth_endpoint: .netlify/functions/auth

locale: hu
site_url: __SITE_URL__
publish_mode: simple
media_folder: assets/img
public_folder: /assets/img
show_preview: false

collections:
  - label: "Weboldal szövegei"
    name: "szovegek"
    files:
'''
out = [head.rstrip('\n')]
for code, name in LANGS:
    data = json.loads((ROOT / f'assets/i18n/{code}.json').read_text(encoding='utf-8'))
    out.append(f'      - label: {q("Szövegek – " + name)}\n        name: {q("szovegek_" + code)}\n        file: {q("assets/i18n/" + code + ".json")}\n        format: json\n        fields:')
    fields(data, '', 10, out)
(ROOT / 'admin/config.yml').write_text('\n'.join(out) + '\n', encoding='utf-8')
print('admin/config.yml kész')
