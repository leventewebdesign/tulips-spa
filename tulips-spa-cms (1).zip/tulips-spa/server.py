#!/usr/bin/env python3
"""Fejlesztői szerver SPA-fallbackkel (History API).

Használat:   python3 server.py [port]        → http://localhost:8000
Minden olyan URL, ami nem létező fájl (pl. /blog, /blog/valami), az index.html-t kapja,
a fájlkiterjesztéssel rendelkező, hiányzó fájlok (pl. /assets/x.js) viszont 404-et.
"""
import os, sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))


class SPAHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.js': 'text/javascript', '.mjs': 'text/javascript',
                      '.json': 'application/json', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json'}

    def __init__(self, *a, **k):
        super().__init__(*a, directory=ROOT, **k)

    def do_GET(self):
        clean = self.path.split('?', 1)[0].split('#', 1)[0]
        if not os.path.exists(self.translate_path(clean)) and not os.path.splitext(clean)[1]:
            self.path = '/index.html'
        return super().do_GET()

    def end_headers(self):
        if self.path.startswith('/assets/'):
            # fejlesztéshez: mindig friss. Élesben: Cache-Control: public, max-age=31536000, immutable + verziózott fájlnevek.
            self.send_header('Cache-Control', 'no-cache')
        super().end_headers()


if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f'TULIPS GROUP – http://localhost:{port}  (Ctrl+C a leállításhoz)')
    ThreadingHTTPServer(('', port), SPAHandler).serve_forever()
