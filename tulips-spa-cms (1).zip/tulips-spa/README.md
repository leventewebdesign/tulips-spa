# TULIPS GROUP – modularizált SPA

A korábbi, egy nagy HTML-ben lévő oldal **modulokra bontott**, History API-s (egyoldalas, SPA) változata.
A megjelenés (dizájn, színek, elrendezés, animációk) **pixelre megegyezik** az eddigivel – ezt képernyőkép-összehasonlítással ellenőriztük (asztali és mobil nézet, minden oldal).

## Gyors indítás

```bash
python3 server.py        # → http://localhost:8000
```

A History API „szép” URL-ekhez (pl. `/blog`, `/faq`) olyan szerver kell, amely az ismeretlen útvonalakat az `index.html`-re irányítja.
A mellékelt `server.py` ezt teszi; élesben lásd: `_redirects` (Netlify/Cloudflare), `vercel.json`, `.htaccess` (Apache), `nginx.conf.example`.
(Dupla kattintással, `file://`-ról nem működik – a JSON nyelvi fájlok betöltéséhez is HTTP kell.)

## Mappaszerkezet

```
index.html                  váz: fejléc, nézet-konténerek, lábléc, főoldal (statikus, gyors első megjelenés)
server.py / build.py        fejlesztői szerver (SPA-fallback) / éles csomag készítése
assets/
  css/                      szekciónként külön fájl – a betöltési sorrend az index.html-ben (a sorrend számít!)
    00-base 01-a11y 02-header 03-hero 04-about 05-services 06-why 07-news 08-faq
    09-contact 10-footer 11-subpages 12-animations 13-scenes 14-rtl
  js/
    main.js                 belépési pont
    config.js               nyelvek, ÚTVONALAK (routes), betűtípus-források
    modules/                i18n, router (History API), nav, lang-switch, form, validation, chat, services,
                            audience, blog, faq, why, legal, counter, reveal, fx, scenes, transitions, components, dom
    data/                   adatok: services, chat, audience, viz (animált SVG-k), cities
  i18n/                     hu.json  en.json  de.json  fr.json  ar.json
  data/                     articles.json (blog/hírek), faq.json
  img/                      logók
```

## Többnyelvűség (i18n)

* Szövegek: `assets/i18n/<nyelv>.json` (beágyazott kulcsok: `nav.about`, `hero.cta1`, `services.7010.title` …).
* A statikus HTML-ben `data-i18n="kulcs"` (szöveg) és `data-i18n-attr="aria-label:kulcs"` (attribútum) jelöli a fordítandó elemeket; a dinamikus részek a `t('kulcs')` függvényt használják:

```js
import { t } from './modules/i18n.js';
t('nav.about');                          // → "Rólunk" / "About" / "Über uns" …
t('a11y.navigated', { title: 'Blog' });  // {title} helyettesítés
```
* Hiányzó kulcs esetén a sorrend: kiválasztott nyelv → angol → magyar → maga a kulcs.
* **Új nyelv:** (1) `assets/i18n/<kód>.json`, (2) egy sor a `config.js` `LANGS` tömbjébe, (3) egy `<li>` a nyelvválasztóba (index.html, `.ls-m`).
* A választás `localStorage`-ben marad meg; az arab (RTL) automatikusan `dir="rtl"`-t kap, az arab betűtípusok csak ekkor töltődnek be.

## Blog / Hírek modul

Új cikk = egy elem az `assets/data/articles.json`-ban + a szövegek az i18n JSON-okban:

```json
{ "id": "a4", "slug": "uj-cikk", "date": "2026-11-02", "scene": "bridge",
  "keys": { "date": "news.4.date", "title": "news.4.title", "lead": "news.4.excerpt", "intro": "news.4.extra" },
  "sections": [{ "h": "blog.a4.s1.h", "p": "blog.a4.s1.p" }],
  "flow": ["blog.flow.needs", "blog.flow.prog"], "takeaways": ["blog.a4.k1"] }
```
A főoldali hírkártyák (`#hirek`), a `/blog` oldal, a tartalomjegyzék és az URL (`/blog/uj-cikk`) automatikusan frissülnek.
A GYIK hasonlóan adatvezérelt: `assets/data/faq.json` (`"home": true` → a főoldali előnézetben is megjelenik).

## History API (URL-átírás, újratöltés nélkül)

Útvonalak: `assets/js/config.js` → `ROUTES`.

| URL | Nézet |
|---|---|
| `/` , `/rolunk`, `/szolgaltatasok`, `/miert-magyarorszag`, `/hirek`, `/gyik`, `/kapcsolat` | főoldal + szekcióhoz görgetés |
| `/blog`, `/blog/<slug>` | blog (cikkhez görgetés) |
| `/faq` | teljes GYIK keresővel |
| `/why-hungary` | Miért Magyarország (részletesen) |
| `/privacy`, `/terms` | jogi oldalak (egyelőre „hamarosan”) |

* Minden belső `<a href="/blog">` automatikusan SPA-navigáció (`pushState`), a böngésző vissza/előre gombja működik (`popstate`).
* Nézetváltáskor az eddigi „függöny” animáció fut; oldalcím, `aria-current`, képernyőolvasós értesítés és fókusz is frissül.
* **Új oldal:** (1) sor a `ROUTES`-ba, (2) `<div class="view" id="view-xxx" hidden></div>` az index.html-ben, (3) `lazyView('xxx', …)` a `main.js`-ben, (4) a nézet modulja (`render`, opcionálisan `update`, `title`, `anchor`, `rerender`).
* Almappában futtatáshoz: `python3 build.py --base /almappa/`.

## Teljesítmény

* **Betűtípusok:** `preconnect` a Google Fonts két hosztjára + nem blokkoló stíluslap (`rel=preload` → `stylesheet`) + `display=swap`; az arab betűk csak arab nyelvnél töltődnek be.
* **SVG:** a gradiensek közös `<defs>`-ben, az ismétlődő megjelenési tulajdonságok (`fill`, `opacity`, `width`, `height` …) CSS-osztályokba emelve (`13-scenes.css`), a nézetek ugyanazt a jelenetet klónozzák / generálják – nincs duplikált markup. Az `index.html` ~135 KB-ról ~70 KB-ra csökkent.
* **JS:** natív ES-modulok, a ritkán használt nézetek (blog, GYIK, Miért Magyarország, jogi oldalak) csak az első látogatáskor töltődnek be (`import()`).
* **CSS:** fejlesztésben szekciónként, élesben `python3 build.py` egyetlen minifikált fájlba fűzi (`dist/`).

## Akadálymentesség (a11y)

* Nyelvválasztó: WAI-ARIA *listbox* (`aria-haspopup`, `aria-expanded`, `aria-controls`, `aria-selected`, `aria-activedescendant`); ↑ ↓ Home End Enter Space Esc Tab, betűgépelés.
* Mobilmenü: `aria-expanded`/`aria-controls`, zárt állapotban `inert`, Esc bezár és a gombra viszi a fókuszt.
* Szolgáltatás- és célközönség-váltó: *tablist* minta (nyilak, Home/End, *roving tabindex*, `aria-selected`, `aria-controls`).
* „Ugrás a tartalomra” link, `aria-current="page"`, élő régió (`role="status"`) az oldalváltás bejelentésére, fókusz a `<main>`-re navigáció után.
* Űrlap: `aria-invalid`, az első hibás mezőre ugrik a fókusz, állapotüzenet `role="status"`.
* Dekoratív elemek (`aria-hidden`): illusztrációk, a „Tulips munkatér” demó, a futószöveg.
* Mozgásérzékenység: `prefers-reduced-motion` esetén nincs animáció / függöny.
* Kontrasztellenőrzés: lásd a „Fejlesztési jegyzet” szakaszt.

## Éles csomag

```bash
python3 build.py            # → dist/ (egyesített, minifikált CSS)
python3 build.py --base /tulips/
```

## Fejlesztési jegyzet (ellenőrzések)

* **Megjelenés:** a régi (több fájlos) és az új (moduláris) változat képernyőképei asztali (1440×900) és mobil (390×844) méretben, minden oldalon összehasonlítva: az eltérés az oldalak pixeleinek ≤ 0,04 %-a (főként a „9%” felirat szubpixel-szintű raszterezése).
* **Kontraszt:** automatikus ellenőrzés (WCAG AA, 4.5:1 / nagy szövegnél 3:1) minden oldalon; egyetlen hibát találtunk: a kiválasztott szolgáltatás-fül kis kódja (piros a sötétkéken, 3.18:1) – ezt világosabb rózsaszínre (`#FF7A99`) cseréltük, minden más változatlan.
* **i18n:** mind az 5 nyelvi fájl pontosan ugyanazt a 280 kulcsot tartalmazza; futásidejű ellenőrzés: egyik nyelven/oldalon sem jelenik meg „nyers” kulcs.
* **Navigáció:** menüpont-kattintás, vissza/előre gomb, mély linkek (`/blog/<slug>`), ismeretlen útvonal → főoldal.


## Új: szolgáltatás-aloldal, teljesítmény, SEO/AI-láthatóság (2026-11)

* **Új oldal:** `/uzleti-szolgaltatasok-budapest` (magyar) és `/business-services-budapest` (angol). Szövegei: `assets/i18n/hu.json` és `en.json` → `sp.*` kulcsok; megjelenítés: `assets/js/modules/services-page.js`. A német/francia/arab nyelv az angol szövegre esik vissza, amíg nincs lefordítva.
* **Előrenderelés:** a keresők és az AI-botok többsége nem futtat JavaScriptet, ezért az oldal kész HTML-ként is létezik. Tartalom- vagy `index.html`-módosítás után: `pip install playwright && playwright install chromium`, majd `python3 prerender.py`, végül `python3 build.py`.
* **SEO/AI:** strukturált adat (JSON-LD: Organization/ProfessionalService, OfferCatalog, FAQPage, BreadcrumbList), kanonikus URL, hreflang, `sitemap.xml`, `robots.txt`, `llms.txt`. A domain a `config.js` `SITE` értékében és a `prerender.py` `SITE` változójában, valamint a sitemap/robots/llms fájlokban van (`tulipsgroup.hu` feltételezés – írják át, ha más).
* **Teljesítmény:** `assets/css/15-perf-mobile.css`, `modules/fx.js`, `modules/perf.js` – nincs blur-szűrős háttér, görgetés közben szünetelnek a jelenet-animációk, képernyőn kívül is állnak, mobilon statikus a hero-jelenet; asztali böngészőben a hero görgetésre a böngésző szálán kívül (CSS scroll-timeline) mozog.
