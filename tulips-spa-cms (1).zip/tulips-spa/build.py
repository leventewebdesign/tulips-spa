#!/usr/bin/env python3
"""Éles (production) csomag készítése  →  dist/

  python3 build.py                 # alapértelmezett: a webhely a domain gyökerében fut ("/")
  python3 build.py --base /tulips/ # ha almappában fut (pl. https://example.com/tulips/)

Mit csinál?
  • a CSS-partialokat (assets/css/*.css, az index.html <!-- css:start/end --> blokkja szerinti sorrendben)
    egyetlen, minifikált assets/css/app.min.css fájlba fűzi  → kevesebb render-blokkoló kérés (jobb FCP)
  • átírja az index.html-t, és a --base értéke szerint a gyökér-hivatkozásokat (href="/..." src="/...")
  • lemásolja a szükséges fájlokat (JS-modulok, i18n JSON-ok, adatok, képek, ikonok, szerver-konfigok)
A JavaScript natív ES-modulként fut; opcionális további csomagolás: npx esbuild assets/js/main.js --bundle --minify --format=esm
"""
import re, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIST = ROOT / 'dist'
base = '/'
if '--base' in sys.argv:
    base = sys.argv[sys.argv.index('--base') + 1]
    base = '/' + base.strip('/') + '/' if base.strip('/') else '/'


def minify(css: str) -> str:
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
    css = re.sub(r'\s+', ' ', css)
    css = re.sub(r'\s*([{};,>])\s*', r'\1', css)
    css = re.sub(r':\s+', ':', css).replace(';}', '}')
    return css.strip()


html = (ROOT / 'index.html').read_text(encoding='utf-8')
m = re.search(r'<!-- css:start -->(.*?)<!-- css:end -->', html, re.S)
files = re.findall(r'href="/(assets/css/[^"]+\.css)"', m.group(1))

if DIST.exists():
    shutil.rmtree(DIST)
shutil.copytree(ROOT, DIST, ignore=shutil.ignore_patterns('dist', 'server.py', 'build.py', 'prerender.py', '__pycache__', '*.md', 'nginx.conf.example', 'assets/css/*.css', 'netlify', 'netlify.toml', 'scripts', '.git', 'node_modules'))
for old in (DIST / 'assets/css').glob('*.css'):
    old.unlink()   # csak az egyesített app.min.css marad
(DIST / 'assets/css').mkdir(parents=True, exist_ok=True)
bundle = '\n'.join(minify((ROOT / f).read_text(encoding='utf-8')) for f in files)
(DIST / 'assets/css/app.min.css').write_text(bundle, encoding='utf-8')

def transform(h: str) -> str:
    h = h.replace(m.group(0), '<link rel="stylesheet" href="/assets/css/app.min.css">')
    if base != '/':
        h = re.sub(r'(href|src)="/(?!/)', rf'\1="{base}', h)
        h = h.replace('<meta name="app-base" content="/">', f'<meta name="app-base" content="{base}">')
    return h


(DIST / 'index.html').write_text(transform(html), encoding='utf-8')
# előrenderelt aloldalak (prerender.py): ugyanaz a CSS-egyesítés és base-átírás
for page in ROOT.glob('*/index.html'):
    if page.parent.name in ('dist', 'assets', 'admin', 'netlify', 'scripts', 'node_modules'):
        continue
    out = DIST / page.parent.name / 'index.html'
    out.parent.mkdir(exist_ok=True)
    out.write_text(transform(page.read_text(encoding='utf-8')), encoding='utf-8')
    print('előrenderelt oldal:', page.parent.name)
size = sum(len((ROOT / f).read_bytes()) for f in files)
print(f'dist/ kész – CSS: {len(files)} fájl, {size//1024} KB → app.min.css {len(bundle.encode())//1024} KB (base: {base})')
